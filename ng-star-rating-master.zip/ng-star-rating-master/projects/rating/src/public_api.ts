/*
 * Public API Surface of rating
 */

// export * from './lib/rating.service';
// export * from './lib/rating.component';
export * from './lib/rating.module';
export * from './components/star-rating/star-rating.component';